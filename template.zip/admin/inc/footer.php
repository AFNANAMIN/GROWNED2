	<div class="clearfix space70"></div>
	<!-- FOOTER -->
	<footer id="footer2">
		
		<div class="footer-bottom container">
			<div class="row">
				<div class="col-md-6">
					<p>&copy; afnan amin ali</p>
				</div>
				<div class="col-md-6">
					
				</div>
			</div>
		</div>
	</footer>
	<!-- FOOTER -->
</div>






<!-- Javascript -->
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/dialogFx.js"></script>
<script src="../js/dialog-js.js"></script>
<script src="../js/navigation/jquery.easing.js"></script>
<script src="../js/flexslider/jquery.flexslider.js"></script>
<script src="../js/navigation/scroll.js"></script>
<script src="../js/navigation/jquery.sticky.js"></script>
<script src="../js/owl-carousel/owl.carousel.min.js"></script>
<script src="../js/isotope/isotope.pkgd.js"></script>
<script src="../js/superfish/js/hoverIntent.js"></script>
<script src="../js/superfish/js/superfish.js"></script>
<script src="../js/tweecool.js"></script>
<script src="../js/jquery.bpopup.js"></script>
<script src="../js/pikaday/pikaday.js"></script>
<script src="../js/classie.js"></script>
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<script src="../js/rs-plugin/js/jquery.themepunch.tools.min.js"></script>   
<script src="../js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script src="../js/jquery.prettyphoto.js"></script>
<script src="../js/script.js"></script>
<script src="../js/booking.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script src="../js/gmap.js"></script>
<script src="../js/gmap2.js"></script>


</body>
</html>